import cmd
import sqlite3
from getpass import getpass
from datetime import datetime


conn = sqlite3.connect('cms.db')
cursor = conn.cursor()


cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0 )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS articles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        pub_date TEXT NOT NULL,
        author_id INTEGER,
        FOREIGN KEY (author_id) REFERENCES users(id) )
''')

conn.commit()

class CMSApp(cmd.Cmd):
    intro = "Welcome to the Content Management System (CMS) CLI app. Type 'help' to see the list of commands."
    prompt = "(CMS) "

    def do_register(self, args):
        """Register a new user."""
        username = input("Enter username: ")
        password = getpass("Enter password: ")

        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
        conn.commit()
        print(f"User '{username}' registered successfully.")

    def do_login(self, args):
        """Log in to the CMS."""
        username = input("Enter username: ")
        password = getpass("Enter password: ")

        cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = cursor.fetchone()

        if user:
            self.current_user = user
            print(f"Logged in as {username}.")
        else:
            print("Invalid username or password.")

    def do_logout(self, args):
        """Log out from the CMS."""
        self.current_user = None
        print("Logged out.")

    def do_create_article(self, args):
        """Create a new article."""
        if not self.current_user:
            print("You need to log in to create an article.")
            return

        title = input("Enter article title: ")
        content = input("Enter article content: ")
        pub_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute("INSERT INTO articles (title, content, pub_date, author_id) VALUES (?, ?, ?, ?)",
                       (title, content, pub_date, self.current_user[0]))
        conn.commit()
        print("Article created successfully.")

    def do_list_articles(self, args):
        """List all articles."""
        cursor.execute("SELECT * FROM articles")
        articles = cursor.fetchall()

        for article in articles:
            print(f"ID: {article[0]}, Title: {article[1]}, Author: {self.get_username_by_id(article[4])}")

    def get_username_by_id(self, user_id):
        """Get username by user ID."""
        cursor.execute("SELECT username FROM users WHERE id=?", (user_id,))
        result = cursor.fetchone()
        return result[0] if result else "Unknown"

    def do_exit(self, args):
        """Exit the CMS."""
        print("Exiting CMS. Goodbye!")
        conn.close()
        return True

if __name__ == "__main__":
    app = CMSApp()
    app.cmdloop()